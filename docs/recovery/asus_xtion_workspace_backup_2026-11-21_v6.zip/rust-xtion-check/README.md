# rust-xtion-check

Smoke test for the Rust-on-Xtion path: the [`openni2`](https://crates.io/crates/openni2)
crate (v0.4.0, released 2025-10-12) talking to the C OpenNI2 stack that the
`openni2-nojava` package installs. Verified to compile with Rust 1.100 and to
link + run against the `libOpenNI2.so` built by that package (full chain:
init -> driver discovery -> PS1080 driver load -> device enumeration).

## Run it

With the `openni2-nojava` package installed and the camera plugged in:

```bash
OPENNI2_REDIST=/usr/lib cargo run --release
```

(`OPENNI2_REDIST` is a **build-time** env var consumed by `openni2-sys`'s
build script — it is the directory containing `libOpenNI2.so`. It is required
even when the library is system-installed, because the build script fails
without it.)

Without a camera the binary still exercises the full stack and exits 0:

```
== rust-xtion-check: openni2 crate smoke test ==
init: OK (libOpenNI2 loaded, driver scan done)
device: none available (Error("DeviceOpen using default: no devices found"))
RESULT: init OK, no camera found - plug in the Xtion and retry
```

With the camera connected you get serial number, firmware version, and five
depth frames with statistics — i.e. the complete
Rust -> openni2 crate -> libOpenNI2.so -> PS1080 driver -> USB round trip.

## Troubleshooting

- `error: Required env var for dynamic libraries missing` — you forgot
  `OPENNI2_REDIST=/usr/lib` on the `cargo run` command line.
- init fails with `Found no files matching '/usr/lib/OpenNI2/Drivers/lib*.so'`
  — the openni2 package is not installed (`makepkg -si` in `openni2-nojava/`).
- Device not found although plugged in — check `lsusb` for `1d27:0601`,
  unplug/replug once so the udev rules apply, and see `xtion_test_cachyos.sh`.
