//! Smoke test for the Rust-on-Xtion path: the `openni2` crate talking to the
//! C OpenNI2 stack that the `openni2-nojava` package installs.
//!
//! With the openni2 package installed (libOpenNI2.so in /usr/lib):
//!   OPENNI2_REDIST=/usr/lib cargo run --release
//!
//! Against a staged redist directory instead:
//!   OPENNI2_REDIST=/path/to/redist LD_LIBRARY_PATH=/path/to/redist cargo run

use openni2::{Device, OniDepthPixel, SensorType, Status};

fn main() -> Result<(), Status> {
    println!("== rust-xtion-check: openni2 crate smoke test ==");

    // Loads and initializes the C library (libOpenNI2.so), scans for drivers
    openni2::init()?;
    println!("init: OK (libOpenNI2 loaded, driver scan done)");

    // Opens the first available device - i.e. your Xtion
    let device = match Device::open_default() {
        Ok(d) => d,
        Err(e) => {
            println!("device: none available ({:?})", e);
            println!("RESULT: init OK, no camera found - plug in the Xtion and retry");
            return Ok(());
        }
    };
    println!("device: opened");
    println!("serial: {}", device.get_serial_number()?);
    println!("firmware: {}", device.get_firmware_version()?);

    let stream = device.create_stream(SensorType::DEPTH)?;
    stream.start()?;
    println!(
        "depth stream: started (hfov {:.1} deg, range {}-{}), reading 5 frames",
        stream.get_horizontal_fov()?,
        stream.get_min_value()?,
        stream.get_max_value()?
    );

    for i in 0..5 {
        let frame = stream.read_frame::<OniDepthPixel>()?;
        let px = frame.pixels();
        let nonzero = px.iter().filter(|&&d| d != 0).count();
        let min = px.iter().filter(|&&d| d != 0).min().copied().unwrap_or(0);
        println!(
            "frame {}: {}x{} (ts {}), {} non-zero pixels, min depth {} mm",
            i + 1,
            frame.width(),
            frame.height(),
            frame.timestamp(),
            nonzero,
            min
        );
    }
    println!("RESULT: PASS - full Rust->C->driver->camera round trip works");
    Ok(())
}
