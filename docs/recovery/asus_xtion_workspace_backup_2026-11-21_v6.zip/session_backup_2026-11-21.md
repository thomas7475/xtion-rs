# Chat Session Backup — ASUS Xtion Linux research

**Version:** 7 (2026-11-22, turn 6) · **Status: Rust-stack question answered with verified evidence — Option A (openni2 crate over the nojava C stack) compiled, linked and executed in sandbox on Rust 1.100.0; options report PDF delivered; smoke-test crate delivered; awaiting user's on-camera run**

> Purpose: upload this file in a new chat to restore full context. It records
> the standing rules, the task, everything that was found and decided, every
> file that was produced, and the state of the current workspace.

## 1. Standing user rules (apply to EVERY future turn)

1. **Communicate in English only** (all replies, all document content).
2. **Zip backup of generated files to `download/`** every turn.
3. **Produce a downloadable session backup** (this file, refreshed with a new
   version/date each turn) so the chat can be continued/resumed later.

## 2. Task history

- **Session 1 (2026-11-19):** user has an ASUS Xtion (1d27:0601) on CachyOS;
  asked about Linux drivers/software and Rust support. Delivered PDF research
  report, setup helper script, HTML cover, session backup.
- **Session 2, turns 1-3 (2026-11-21):** files restored after recycle; how to
  test the camera (NOT UVC — only OpenNI 2 works; test script delivered);
  fixed shelly syntax + false-alarm rules + g++ probe issues (scripts v1.1).
- **Session 2, turn 4 (2026-11-21):** AUR openni2 PKGBUILD security review:
  **verdict clean** (5/7 sources hash-match Debian's archive, tarball hash
  verified, patches benign, builds on GCC 14). Scripts v1.2.
- **Session 2, turn 5 (2026-11-21):** user hit `jdk-openjdk conflicts with
  jre-openjdk` during shelly install (answered n). Delivered
  `openni2-nojava/` — modified PKGBUILD 2.2.0-3 dropping the unused Java/doc
  build, all 8 sha256 pins byte-identical to AUR, end-to-end sandbox
  simulation PASS. Setup script v1.3 (prefers bundled local build).
- **Session 2, turn 6 (2026-11-22):** user asked for options to get a complete
  Rust stack with the driver running. Researched the ecosystem (Nov 2026),
  VERIFIED Option A end to end in a container (Rust 1.100.0: cargo build +
  full init/driver-load/enumeration chain against the nojava-built
  libOpenNI2.so), delivered the 12-page options report PDF
  `asus_xtion_rust_stack_options.pdf` and the smoke-test crate
  `rust-xtion-check/`.

## 3. The Rust-stack options (turn-6 answer, details in the report PDF)

- **A — Rust bindings over the C stack (RECOMMENDED, verified):**
  openni2-nojava package + `openni2` crate 0.4.0. Build quirk: the crate's
  build script REQUIRES `OPENNI2_REDIST=/usr/lib` (or _64) at build time even
  when the lib is system-installed. Effort: under an hour.
- **B — vendored cargo build:** build.rs compiles OpenNI2 from the
  hash-verified tarball + 6 patches during cargo build (the verified make
  target list is in the nojava PKGBUILD). One-command builds, no package
  dependency. 1-2 days.
- **C — Rust driver inside OpenNI2:** replace libPS1080.so with a Rust .so.
  Plugin mechanics (verified in source): framework globs
  /usr/lib/OpenNI2/Drivers/lib*.so, chdirs there, dlopens bare names, dlsyms
  the oniDriver* C exports. Entry points are plain C, but oniDriverCreate
  must return a C++ DriverBase (hand-built Itanium vtable). 2-4 weeks.
- **D — pure-Rust driver (the real complete stack):** nusb transport +
  PS1080 protocol port. Facts extracted: bulk-in endpoints depth 0x81 /
  image 0x82 / audio+misc 0x83 (firmware 3.0/4.0+; legacy 0x82 image, 0x83
  depth, 0x86 audio, bulk ctrl 0x04/0x85, auto-detected by trying 0x81
  first); vendor control-transfer command protocol; packed-11-bit depth
  codecs in PS1080/Formats; shift-to-depth LUT from per-device calibration
  (PS1080/DDK/XnShiftToDepth.cpp + DepthUtils, 721 LOC); PS1080 tree = 210
  files / 38,844 LOC C++, XnLib 47,768 LOC (only USB/OS/log subset needed).
  No such driver exists anywhere (checked crates.io + GitHub + kornia
  sensor-rt). 4-8+ weeks, milestones M1-M7 in the report.
- **E — ROS 2:** no maintained openni2 node exists (ROS 1 only, EOL); wrap
  A or D in a component; rclrs still experimental.

## 4. Turn-6 verification evidence (Option A works)

- Rust 1.100.0 (2026-11-09 stable) + cargo 1.100.0 installed via rustup with
  `RUSTUP_HOME=/home/z/my-project/.rustup CARGO_HOME=/home/z/my-project/.cargo`
  (in-project, no system writes).
- `cargo build` of openni2-sys 1.1.1 + openni2 0.4.0 + rust-xtion-check:
  **2.4 s, success** — the 2015-edition crate compiles on current rustc.
- Runtime: binary loaded the nojava-built libOpenNI2.so (via LD_LIBRARY_PATH
  staging), ran oniInitialize through FFI, and — with an LD_PRELOAD shim
  standing in for the root-only /usr/lib/OpenNI2/Drivers — loaded BOTH
  libPS1080.so and libOniFile.so, resolved their oniDriver* exports, and
  enumerated devices, exiting 0 with "no devices found" (no camera in the
  container). On the user's machine no shim is needed.
- The shim (scripts/driver_path_preload.c) documents the exact driver-loading
  mechanics: glob64 → chdir(dir) → dlopen(bare .so names relative to CWD) →
  dlsym. Symbol interposition of versioned glibc references required
  .symver aliases + a version script (glob64@GLIBC_2.27-ish, realpath@2.3,
  chdir@2.2.5, dlopen@2.34).
- crates verified via crates.io API: openni2 0.4.0 (2025-10-12, 6,743 DL),
  openni2-sys 1.1.1 (2020-03-26), nusb 0.2.9 (2026-10-24, 2.35M DL, pure
  Rust USB), rusb 0.9.4 (2024-04-27, 10.4M DL).

## 5. Deliverables (all under /home/z/my-project/download/)

| File | What it is |
|---|---|
| `asus_xtion_rust_stack_options.pdf` | 12-page A4 options report (cover + TOC + 9 chapters + sources; Figure 1 stack diagram; 4 tables; pdf_qa PASS). |
| `rust-xtion-check/` | Verified smoke-test crate: Cargo.toml (openni2 = "0.4"), src/main.rs, README with build/run/troubleshooting. Run: `OPENNI2_REDIST=/usr/lib cargo run --release`. |
| `asus_xtion_linux_research_report.pdf` | Session-1 research report (unchanged). |
| `xtion_setup_cachyos.sh` / `xtion_test_cachyos.sh` | v1.3 / v1.2 (unchanged this turn). |
| `openni2-nojava/` | Turn-5 package (unchanged). |
| `asus_xtion_report_cover.html`, `diagram_stack.png` | Session-1 artifacts (unchanged). |
| `session_backup_2026-11-21.md` | This file (v7). |
| `asus_xtion_workspace_backup_2026-11-21_v6.zip` | Turn-6 zip (CURRENT). Older zips v1-v5 kept. |

## 6. Workspace state (2026-11-22, after turn 6)

- `scripts/` additions this turn: `rust_options_content.py` (report prose),
  `gen_rust_options_pdf.py` (ReportLab builder + cover merge),
  `rust_options_cover.html` + `rust_options_diagram.html` (sources),
  `snap_diagram.js` (Playwright diagram screenshots),
  `driver_path_preload.c` (sandbox-only driver-path shim),
  `prepare_rust_linktest.sh` (builds the C redist for cargo link tests),
  `extract_crate_api.py`, `verify_options_pdf.py` (programmatic PDF checks).
  Plus all earlier scripts (verify_aur_pkgbuild.sh, simulate_nojava_build.sh,
  reconstruct_aur_sources.py, setup/test script copies).
- Rust toolchain lives in-project: `.cargo/`, `.rustup/` (do not zip).
- `/tmp/xtion-verify/` (recycled between turns): tarball.tar.gz
  (sha256-verified), rust-test-tree/ (patched build tree), redist/
  (libOpenNI2.so + drivers for link tests), deps/ (libusb/libudev headers),
  deps-gl/ (GL headers from turn 5, still documented), cargo-target/,
  rust_options_cover.pdf + rust_options_diagram.png, preload .so + map.
  Rebuild recipe: scripts/prepare_rust_linktest.sh, then cargo with
  OPENNI2_REDIST=/tmp/xtion-verify/redist.

## 7. Gotchas learned (cumulative)

- openni2-sys REQUIRES the OPENNI2_REDIST(_64) env var at BUILD time even
  with the library system-installed; without it the build script panics.
- OpenNI2 2.2.0 driver loading = glob64 of /usr/lib/OpenNI2/Drivers/lib*.so,
  then chdir into that dir, then dlopen by BARE file name (relative to CWD),
  then dlsym of the oniDriver* C exports. This is why staging a redist dir
  never worked at runtime before, and why the sandbox needed a chdir-redirect
  shim. Also: oniInitialize ERRORS (not just returns empty) when zero
  drivers are found.
- Interposing versioned glibc symbols from an LD_PRELOAD .so needs
  .symver aliases plus a --version-script declaring the version nodes;
  libOpenNI2 references glob64, realpath@GLIBC_2.3, chdir@GLIBC_2.2.5,
  dlopen@GLIBC_2.34.
- `pdf.py convert.blueprint` expects a JSON blueprint, NOT raw HTML — for
  diagram PNGs use a direct Playwright screenshot at deviceScaleFactor 2
  (scripts/snap_diagram.js); PDFs still only via html2poster.js /
  html2pdf-next.js.
- pdf_qa fails on sub-point page-size mismatch: normalize the merged cover
  with a 0.3pt tolerance (page.scale_to A4).
- This session's model cannot read images — visual PDF checks must be
  programmatic (scripts/verify_options_pdf.py pattern: pymupdf text/word
  extraction + placeholder scan + structure checks).
- Earlier gotchas (still valid): jdk/jre conflict; default `make` builds the
  Java wrapper; Debian GL header split (libgl-dev/libglx-dev/libglu
  pool/main/libg/libglu/); freedesktop GitLab + packages.debian.org blocked,
  deb.debian.org pool + crates.io API fine; shelly fuzzy-searches bad
  subcommands; OpenNI2 sample code is C++ (compile with g++); SimpleDocTemplate
  'Later' template override; zero padding on narrow gap columns.

## 8. Open threads (if the user continues)

- User runs the real test: build+install openni2-nojava, plug in the camera,
  `cd rust-xtion-check && OPENNI2_REDIST=/usr/lib cargo run --release` —
  expect serial, firmware, and five depth frames with statistics.
- If they want the pure-Rust driver (Option D): start the M1-M2 spike
  (nusb: open 1d27:0601, read firmware version, stream RGB); validate M4
  (shift-to-depth) against Option A's output on the same scene.
- If they want Option B: build.rs vendoring — all sources + the verified
  target list are in openni2-nojava/.
- Report regeneration: edit scripts/rust_options_content.py, rerun
  scripts/gen_rust_options_pdf.py, then meta.brand + pdf_qa +
  verify_options_pdf.py.
