#!/usr/bin/env bash
# =============================================================================
# ASUS Xtion (USB 1d27:0601) setup helper for CachyOS / Arch Linux
#
# What it does:
#   1. Checks that the camera is present and on a USB 2.0 link (recommended)
#   2. Installs the OpenNI 2 framework + PS1080 driver from the AUR
#   3. Makes sure the PrimeSense udev rules are installed and reloaded
#   4. Verifies the library and driver files
#   5. Optionally launches NiViewer (--test) to see depth + color streams
#
# Usage:
#   ./xtion_setup_cachyos.sh            # install and verify
#   ./xtion_setup_cachyos.sh --test     # ... then launch NiViewer
#   ./xtion_setup_cachyos.sh --python   # also pip-install the Python bindings
#
# Notes:
#   - Needs an AUR helper: shelly (CachyOS default), paru, or yay.
#     Without any of them the script prints manual makepkg instructions.
#   - Parts of this script need root (sudo) for the udev rules.
#   - Prefer a USB 2.0 port. Old Xtion firmware fails on USB 3.0 ports with
#     "not enough bandwidth" in dmesg.
#
# Changelog:
#   v1.3 (2026-11-21) - prefer the bundled openni2-nojava local build
#     (makepkg / shelly build -s -l) so the install never pulls a JDK that
#     conflicts with an installed jre-openjdk; AUR install kept as fallback.
#   v1.2 (2026-11-21) - detect the AUR package's file names: udev rules as
#     60-openni2-usb.rules, viewer binary as NiViewer2.
#   v1.1 (2026-11-21) - shelly: use "shelly install aur openni2" (the old
#     "shelly aur install openni2" wording is invalid syntax; shelly then
#     fuzzy-searches the whole string and offers wrong packages); check the
#     udev rules CONTENT for PID 0601 (was checking the filename); verify
#     the library immediately after the install step; accept libOpenNI2.so*.
# =============================================================================

set -u

WANT_TEST=0
WANT_PYTHON=0
for arg in "$@"; do
  case "$arg" in
    --test)    WANT_TEST=1 ;;
    --python)  WANT_PYTHON=1 ;;
    -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $arg (try --help)"; exit 2 ;;
  esac
done

fail() { echo "ERROR: $*" >&2; exit 1; }
info() { echo -e "\\n== $* =="; }

# ---------------------------------------------------------------- 1. device
info "Checking for the ASUS Xtion (1d27:0601)"
if lsusb | grep -q '1d27:0601'; then
  echo "Found: $(lsusb | grep '1d27:0601')"
else
  echo "NOT found. Plug the camera in (directly, not through a hub) and retry."
  echo "Related IDs in the same family: 1d27:0600 (older, OpenNI 1 units)."
  exit 1
fi

info "USB link speed (480M = USB 2.0 is what you want)"
lsusb -t
if lsusb -t | grep -q '5000M'; then
  echo "NOTE: something on your bus runs at 5000M (USB 3.x). If the Xtion"
  echo "      fails with 'not enough bandwidth' in dmesg, move it to a"
  echo "      USB 2.0 port - that is a known Xtion firmware quirk."
fi

# ------------------------------------------------------------ 2. install
info "Installing openni2"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOCAL_PKG="$SCRIPT_DIR/openni2-nojava/PKGBUILD"
if [ -f "$LOCAL_PKG" ]; then
  # Bundled no-Java build of the AUR package: identical, hash-pinned
  # sources, but the build skips the Java wrapper + javadoc, so nothing
  # pulls a JDK (jdk-openjdk) that would conflict with an installed
  # jre-openjdk. Camera functionality is identical.
  echo "Using the bundled openni2-nojava build (no Java dependency)"
  if ! pacman -Qg base-devel >/dev/null 2>&1; then
    echo "base-devel group looks incomplete - installing it first"
    sudo pacman -S --needed base-devel || fail "could not install base-devel"
  fi
  if command -v shelly >/dev/null 2>&1; then
    (cd "$SCRIPT_DIR/openni2-nojava" && shelly build -s -l ./PKGBUILD) \
      || (cd "$SCRIPT_DIR/openni2-nojava" && makepkg -si) \
      || fail "local build failed - see the output above"
  else
    (cd "$SCRIPT_DIR/openni2-nojava" && makepkg -si) \
      || fail "local build failed - see the output above"
  fi
elif command -v shelly >/dev/null 2>&1; then
  # shelly syntax is "install aur <pkg>" (or "-Ia <pkg>"). "shelly aur
  # install <pkg>" is NOT valid - shelly would fuzzy-search the whole string
  # and offer unrelated packages (e.g. arch-install-scripts).
  # NOTE: the AUR package depends on java-environment (a JDK); if you keep
  # jre-openjdk installed, prefer the bundled openni2-nojava build above.
  shelly install aur openni2 --needed
elif command -v paru >/dev/null 2>&1; then
  paru -S --needed openni2
elif command -v yay >/dev/null 2>&1; then
  yay -S --needed openni2
else
  echo "No bundled openni2-nojava directory and no AUR helper found. Manual route:"
  echo "  sudo pacman -S --needed base-devel git"
  echo "  git clone https://aur.archlinux.org/openni2.git && cd openni2"
  echo "  makepkg -si"
  echo "If the release build misbehaves, try openni2-git (develop branch)."
  exit 1
fi

# verify immediately: a helper can silently pick the WRONG package
LIB="$(find /usr/lib -maxdepth 3 -name 'libOpenNI2.so*' 2>/dev/null | sort | head -1)"
if [ -z "$LIB" ]; then
  echo ""
  echo "libOpenNI2.so NOT found - openni2 was NOT installed by the helper"
  echo "(watch out for wrong fuzzy-match picks above). Manual route:"
  echo "  sudo pacman -S --needed base-devel git"
  echo "  git clone https://aur.archlinux.org/openni2.git && cd openni2"
  echo "  makepkg -si"
  fail "openni2 is not installed"
fi
echo "Installed: $LIB"

# ----------------------------------------------------------------- 3. udev
info "Checking PrimeSense udev rules"
RULES=''
for f in /usr/lib/udev/rules.d/60-openni2-usb.rules \
         /usr/lib/udev/rules.d/557-primesense-usb.rules \
         /usr/lib/udev/rules.d/55-primesense-usb.rules \
         /etc/udev/rules.d/557-primesense-usb.rules; do
  [ -f "$f" ] && RULES="$f"
done
if [ -n "$RULES" ] && grep -q '0601' "$RULES" 2>/dev/null; then
  echo "Rules present and covering PID 0601: $RULES"
else
  echo "Rules missing or not covering PID 0601 - installing the upstream file to /etc/udev/rules.d/"
  sudo curl -fsSL -o /etc/udev/rules.d/557-primesense-usb.rules \
    https://raw.githubusercontent.com/structureio/openni2/master/Packaging/Linux/primesense-usb.rules \
    || fail "could not download udev rules (check network)"
  RULES=/etc/udev/rules.d/557-primesense-usb.rules
  if ! grep -q '0601' "$RULES" 2>/dev/null; then
    echo "WARNING: downloaded rules still lack PID 0601 - add this line to $RULES:"
    echo '  SUBSYSTEM=="usb", ATTR{idProduct}=="0601", ATTR{idVendor}=="1d27", MODE:="0666", OWNER:="root", GROUP:="video"'
  fi
fi
sudo udevadm control --reload-rules
sudo udevadm trigger
echo "Rules reloaded. If the camera was just plugged in, unplug and replug it."

# ------------------------------------------------------- 4. verify drivers
info "Verifying the OpenNI 2 driver files"
echo "Framework: $LIB"
DRIVER_DIR="$(dirname "$LIB")/openni2/Drivers"
[ -d "$DRIVER_DIR" ] || DRIVER_DIR="$(dirname "$LIB")/OpenNI2/Drivers"
if [ -d "$DRIVER_DIR" ]; then
  echo "Driver directory: $DRIVER_DIR"
  ls -l "$DRIVER_DIR" | grep -i 'PS1080\|Sensor' || \
    echo "WARNING: no PS1080 driver file spotted in $DRIVER_DIR"
else
  echo "WARNING: no openni2/Drivers directory found near $LIB"
fi
groups | grep -qw video || \
  echo "NOTE: your user is not in the 'video' group; run: sudo usermod -aG video \$USER (then re-login)"

if [ "$WANT_PYTHON" = 1 ]; then
  info "Installing Python bindings (official PrimeSense wrappers)"
  pip install --user primesense
fi

# ------------------------------------------------------------------ 5. test
info "Test tool"
VIEWER=''
for v in NiViewer2 NiViewer; do
  command -v "$v" >/dev/null 2>&1 && VIEWER="$v"
done
if [ -n "$VIEWER" ]; then
  echo "Viewer found: $VIEWER ($(command -v "$VIEWER"))"
  if [ "$WANT_TEST" = 1 ]; then
    echo "Launching $VIEWER (close its window to exit)..."
    "$VIEWER"
  else
    echo "Run '$0 --test' or just '$VIEWER' to see depth + color streams."
  fi
else
  echo "No viewer in PATH. The AUR openni2 package installs one as NiViewer2;"
  echo "if it is missing, build the tree once:"
  echo "  git clone https://github.com/structureio/openni2.git && cd openni2 && make"
  echo "  ./Bin/x64-Release/NiViewer"
fi

echo
echo "Done. Quick recap:"
echo "  - framework + PS1080 driver: installed from AUR (openni2)"
echo "  - udev rules: $RULES (mode 0666, group video)"
echo "  - prefer a USB 2.0 port; check 'dmesg' if enumeration fails"
echo "  - Rust: cargo add openni2  (links the system library this installed)"
