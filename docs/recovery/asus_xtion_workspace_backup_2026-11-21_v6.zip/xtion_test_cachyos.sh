#!/usr/bin/env bash
# =============================================================================
# ASUS Xtion (1d27:0601) health check for CachyOS / Arch Linux
#
# Run this AFTER xtion_setup_cachyos.sh has installed the OpenNI 2 stack.
# It walks the whole chain - USB link, kernel log, udev permissions, OpenNI 2
# library + PS1080 driver - and then grabs REAL frames headlessly: it compiles
# a tiny C probe against libOpenNI2 (or, with --python, uses the PrimeSense
# Python bindings) and reads one depth frame and one color frame.
#
# Usage:
#   ./xtion_test_cachyos.sh             # full check + headless frame grab
#   ./xtion_test_cachyos.sh --viewer    # ... then launch NiViewer (GUI)
#   ./xtion_test_cachyos.sh --python    # frame grab via python 'primesense'
#   ./xtion_test_cachyos.sh --skip-grab # checks only, no frame grab
#
# Exit code: 0 = all checks passed, 1 = at least one failure.
#
# NOTE: the Xtion is NOT a UVC camera - it never shows up as /dev/video*.
# v4l2-ctl / qv4l2 / cheese / OBS cannot see it. The only test path is
# OpenNI 2 (this script + NiViewer).
#
# Changelog:
#   v1.2 (2026-11-21) - also detect the AUR package's file names: udev rules
#     as 60-openni2-usb.rules and the viewer as NiViewer2.
#   v1.1 (2026-11-21) - compile the probe with g++ (it is C++; gcc could
#     never compile it); stage a local redist dir so the PS1080 driver is
#     found no matter whether the package used openni2/Drivers or
#     OpenNI2/Drivers; guard against a missing Drivers dir; accept
#     libOpenNI2.so* (not just the dev-symlink name).
# =============================================================================

export LC_ALL=C
set -u

WANT_VIEWER=0
WANT_PYTHON=0
WANT_GRAB=1
for arg in "$@"; do
  case "$arg" in
    --viewer)    WANT_VIEWER=1 ;;
    --python)    WANT_PYTHON=1 ;;
    --skip-grab) WANT_GRAB=0 ;;
    -h|--help)   grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $arg (try --help)"; exit 2 ;;
  esac
done

PASS=0; FAIL=0; WARN=0
NEXT_STEPS=()
ok()   { PASS=$((PASS+1)); echo "  [ PASS ] $*"; }
bad()  { FAIL=$((FAIL+1)); echo "  [ FAIL ] $*"; }
warn() { WARN=$((WARN+1)); echo "  [ WARN ] $*"; }
step() { echo; echo "== $* =="; }
hint() { NEXT_STEPS+=("$*"); }

# ---------------------------------------------------------------- 1. device
step "1. USB device present (1d27:0601)"
HAS_LSUSB=1
if ! command -v lsusb >/dev/null 2>&1; then
  bad "lsusb not found - install usbutils first: sudo pacman -S usbutils"
  hint "sudo pacman -S usbutils, then re-run this script"
  HAS_LSUSB=0
  lsusb() { :; }   # let the remaining checks degrade gracefully
fi
USB_LINE=""
[ "$HAS_LSUSB" = 1 ] && USB_LINE="$(lsusb 2>/dev/null | grep '1d27:0601')"
if [ -n "$USB_LINE" ]; then
  ok "found: $USB_LINE"
elif [ "$HAS_LSUSB" = 1 ] && lsusb 2>/dev/null | grep -q '1d27:0600'; then
  bad "found a 1d27:0600 unit - that is the OLDER OpenNI 1 generation;"
  echo "         this script tests OpenNI 2 hardware (0601)."
  hint "0600 units need the legacy OpenNI 1 stack (AUR package: openni)"
elif [ "$HAS_LSUSB" = 1 ]; then
  bad "no 1d27:0601 in lsusb - camera not enumerated at all"
  hint "plug the camera in DIRECTLY (no hub), preferably a USB 2.0 port, then re-run"
fi

BUSNUM=0; DEVNUM=0
if [ -n "$USB_LINE" ]; then
  BUSNUM="$(printf '%s' "$USB_LINE" | sed 's/^Bus 0*\([0-9]*\).*/\1/')"
  DEVNUM="$(printf '%s' "$USB_LINE" | sed 's/^Bus [0-9]* Device 0*\([0-9]*\).*/\1/')"

  # ------------------------------------------------------- 2. link speed
  step "2. USB link speed (480M = USB 2.0 is what you want)"
  BUS2="$(printf '%02d' "$BUSNUM")"
  SPEED="$(lsusb -t 2>/dev/null | awk -v b="$BUS2" -v d="$DEVNUM" '
    $0 ~ "^/:  Bus " b "\\." { inbus = 1; next }
    /^\/:/  { inbus = 0 }
    inbus && $0 ~ ("Dev " d ",") { print $NF; exit }
  ')"
  case "$SPEED" in
    480M)  ok "camera is on a USB 2.0 link (480M)" ;;
    5000M|10000M) warn "camera is on a USB $SPEED link - old Xtion firmware often"
                    echo "         fails there with 'not enough bandwidth'; use a USB 2.0 port"
                    hint "if dmesg shows bandwidth errors below, move the camera to a USB 2.0 port" ;;
    *)     warn "could not determine link speed (got: '${SPEED:-nothing}'); check 'lsusb -t' by hand" ;;
  esac

  # ------------------------------------------------ 3. kernel log (dmesg)
  step "3. Kernel log: USB errors / bandwidth"
  DMESG_OUT="$(dmesg 2>/dev/null || sudo -n dmesg 2>/dev/null || true)"
  if [ -z "$DMESG_OUT" ]; then
    warn "could not read dmesg (needs root here); check manually:"
    echo "         sudo dmesg | grep -iE '1d27|bandwidth'"
  else
    if printf '%s' "$DMESG_OUT" | grep -qiE 'not enough bandwidth|can.?t set config'; then
      bad "kernel log shows the classic USB 3.0 bandwidth failure"
      hint "move the camera to a USB 2.0 port, or flash firmware FW579-RD1081-112v2 (see report section 5)"
    else
      ok "no bandwidth / config errors in the kernel log"
    fi
    LAST="$(printf '%s' "$DMESG_OUT" | grep -i '1d27' | tail -n 2)"
    [ -n "$LAST" ] && { echo "         last 1d27-related kernel lines:"; printf '%s\n' "$LAST" | sed 's/^/           /'; }
  fi

  # ------------------------------------------- 4. udev node permissions
  step "4. udev permissions on the device node"
  RULES=''
  for f in /usr/lib/udev/rules.d/60-openni2-usb.rules \
           /usr/lib/udev/rules.d/557-primesense-usb.rules \
           /usr/lib/udev/rules.d/55-primesense-usb.rules \
           /etc/udev/rules.d/557-primesense-usb.rules; do
    [ -f "$f" ] && RULES="$f"
  done
  if [ -n "$RULES" ]; then
    if grep -q '0601' "$RULES" 2>/dev/null; then
      ok "PrimeSense udev rules present and cover PID 0601 ($RULES)"
    else
      warn "rules file exists but does not mention PID 0601: $RULES"
    fi
  else
    bad "no PrimeSense udev rules installed"
    hint "run ./xtion_setup_cachyos.sh (installs 557-primesense-usb.rules), then replug the camera"
  fi

  NODE="/dev/bus/usb/$(printf '%03d' "$BUSNUM")/$(printf '%03d' "$DEVNUM")"
  if [ -e "$NODE" ]; then
    MODE="$(stat -c '%a' "$NODE" 2>/dev/null)"
    OWNER="$(stat -c '%U:%G' "$NODE" 2>/dev/null)"
    case "$MODE" in
      666) ok "device node $NODE is world-open ($MODE $OWNER) - rule is active" ;;
      660) if [ "$OWNER" = "root:video" ] && groups | grep -qw video; then
             ok "device node $NODE is 660 root:video and you are in 'video'"
           elif [ "$OWNER" = "root:video" ]; then
             bad "node is 660 root:video but your user is NOT in the video group"
             hint "sudo usermod -aG video \$USER  (then log out and back in)"
           else
             bad "node is $MODE $OWNER - the udev rule has not been applied to it"
             hint "sudo udevadm control --reload-rules && sudo udevadm trigger; then unplug/replug the camera"
           fi ;;
      *)   bad "device node $NODE has unexpected perms: $MODE $OWNER"
           hint "reload udev rules and replug (see xtion_setup_cachyos.sh step 3)" ;;
    esac
  else
    warn "device node $NODE not found - odd, lsusb sees the camera"
  fi
else
  echo "(device absent - skipping checks 2-4)"
fi

# ---------------------------------------- 5. OpenNI 2 stack on disk
step "5. OpenNI 2 library + PS1080 driver"
LIB="$(find /usr/lib -maxdepth 3 -name 'libOpenNI2.so*' 2>/dev/null | sort | head -1)"
if [ -n "$LIB" ]; then
  ok "framework: $LIB"
else
  bad "libOpenNI2.so not found - the OpenNI 2 stack is not installed"
  hint "run ./xtion_setup_cachyos.sh  (AUR package: openni2)"
fi
DRIVER_DIR=""
if [ -n "$LIB" ]; then
  LIBDIR="$(dirname "$LIB")"
  for d in "$LIBDIR/openni2/Drivers" "$LIBDIR/OpenNI2/Drivers"; do
    [ -d "$d" ] && DRIVER_DIR="$d"
  done
  if [ -n "$DRIVER_DIR" ]; then
    if ls "$DRIVER_DIR" | grep -qi 'PS1080'; then
      ok "PS1080 driver present in $DRIVER_DIR"
    else
      bad "Drivers dir exists but no PS1080 library in it: $DRIVER_DIR"
      hint "reinstall the openni2 package (the AUR build may have failed)"
    fi
  else
    bad "no openni2/Drivers directory near $LIB"
    hint "reinstall the openni2 AUR package"
  fi
fi
groups | grep -qw video || warn "your user is not in the 'video' group (fine if the udev rule sets mode 0666)"

# ------------------------------------------- 6. headless frame grab
# OpenNI locates its drivers at <dir-of-libOpenNI2.so>/OpenNI2/Drivers, but
# packages disagree on the case (openni2/Drivers vs OpenNI2/Drivers). Staging
# a local copy of the lib with a symlinked Drivers dir makes the probe work
# with either layout. (The OPENNI2_REDIST64 env var is NOT read by the
# current OpenNI version - the module directory is what counts.)
stage_redist() {
  [ -n "$REDIST" ] && return 0
  REDIST="$(mktemp -d)"
  mkdir -p "$REDIST/OpenNI2"
  if cp -L "$LIB" "$REDIST/libOpenNI2.so" 2>/dev/null; then
    ln -sfn "$DRIVER_DIR" "$REDIST/OpenNI2/Drivers"
  else
    rm -rf "$REDIST"; REDIST=""
  fi
}
step "6. Headless frame grab (opens the camera and reads real frames)"
GRAB_RESULT="skipped"
REDIST=""; LINKDIR=""
if [ "$WANT_GRAB" = 0 ]; then
  warn "skipped (--skip-grab)"
elif [ -z "$LIB" ]; then
  bad "cannot grab frames: OpenNI 2 not installed (see step 5)"
  GRAB_RESULT="no-stack"
elif [ -z "$DRIVER_DIR" ]; then
  bad "cannot grab frames: no Drivers directory found (see step 5)"
  GRAB_RESULT="no-driver"
elif [ "$WANT_PYTHON" = 1 ]; then
  # ---- Python route: official PrimeSense bindings -------------------
  if ! python3 -c 'import primesense' >/dev/null 2>&1; then
    echo "  installing the primesense bindings: pip install --user primesense"
    pip install --user primesense >/dev/null 2>&1 || \
      warn "pip install primesense failed - is pip installed?"
  fi
  if python3 -c 'import primesense' >/dev/null 2>&1; then
    stage_redist
    echo "  running the Python probe (timeout 20 s)..."
    OUT="$(timeout 20 python3 - "${REDIST:-$LIBDIR}" 2>&1 <<'PYEOF'
import sys
try:
    from primesense import openni2
except ImportError:
    print("PROBE_FAIL stage=import rc=2 msg=primesense module missing"); sys.exit(2)
libdir = sys.argv[1] if len(sys.argv) > 1 else None
try:
    openni2.initialize(libdir)
except Exception as e:
    print("PROBE_FAIL stage=init rc=2 msg=%s" % e); sys.exit(2)
try:
    dev = openni2.Device.open_any()
except Exception as e:
    print("PROBE_FAIL stage=open rc=3 msg=%s" % e); sys.exit(3)
try:
    info = openni2.Device.get_device_info(dev)
    print("device: %s / %s" % (getattr(info, "name", "?"), getattr(info, "vendor", "?")))
except Exception:
    pass
try:
    depth = dev.create_depth_stream(); depth.start()
    f = depth.read_frame()
    print("depth: %dx%d" % (f.width, f.height))
except Exception as e:
    print("PROBE_FAIL stage=depth rc=4 msg=%s" % e); sys.exit(4)
try:
    color = dev.create_color_stream(); color.start()
    c = color.read_frame()
    print("color: %dx%d" % (c.width, c.height))
    rc = 0
except Exception:
    print("color: not available (depth-only unit?)")
    rc = 1
try:
    depth.stop(); dev.close(); openni2.shutdown()
except Exception:
    pass
sys.exit(rc)
PYEOF
)"
    RC=$?
    printf '%s\n' "$OUT" | sed 's/^/    /'
    case $RC in
      0) ok "frame grab OK: depth AND color streams verified - camera works"; GRAB_RESULT="depth+color" ;;
      1) ok "frame grab OK: depth verified; no color sensor (depth-only Xtion Pro)"; GRAB_RESULT="depth-only" ;;
      2) bad "could not initialize OpenNI 2 (library problem - see step 5)"; GRAB_RESULT="init-fail" ;;
      3) bad "OpenNI 2 found no device (permissions? PS1080 driver? see failures above)"
         hint "if it works with 'sudo', it is udev/group; otherwise reinstall openni2"
         GRAB_RESULT="no-device" ;;
      4) bad "depth stream failed on an opened device"; GRAB_RESULT="depth-fail" ;;
      124) bad "no frame arrived within 20 s (camera stalled? try replug / another port)"; GRAB_RESULT="timeout" ;;
      *)  bad "probe exited with code $RC"; GRAB_RESULT="error" ;;
    esac
  else
    warn "primesense Python bindings unavailable; falling back to the C probe"
    WANT_PYTHON=0
  fi
fi
if [ "$WANT_GRAB" = 1 ] && [ -n "$LIB" ] && [ "$WANT_PYTHON" = 0 ]; then
  # ---- C route: compile a minimal probe against libOpenNI2 ----------
  PROBE_SRC=''
  HDR=''
  for h in /usr/include/openni2/OpenNI.h /usr/include/OpenNI.h; do
    [ -f "$h" ] && HDR="$h"
  done
  if ! command -v g++ >/dev/null 2>&1; then
    warn "g++ not found - install base-devel, or re-run with --python"
    hint "sudo pacman -S --needed base-devel"
    GRAB_RESULT="no-compiler"
  elif [ -z "$HDR" ]; then
    warn "OpenNI.h header not found (AUR package should ship /usr/include/openni2/)"
    hint "reinstall openni2, or re-run with --python"
    GRAB_RESULT="no-header"
  else
    stage_redist
    LINKDIR="${REDIST:-$(mktemp -d)}"
    cat > "$LINKDIR/xtion_probe.cpp" <<'CEOF'
/* Minimal OpenNI 2 probe: open any device, read one depth frame,
   then try one color frame. Exit codes: 0 = depth+color, 1 = depth only,
   2 = init fail, 3 = open fail, 4/5/6 = depth fail, 7/8 = color fail. */
#include <OpenNI.h>
#include <cstdio>
#include <cstdlib>

static void die(int code, const char* stage, openni::Status rc) {
    std::printf("PROBE_FAIL stage=%s rc=%d msg=%s\n", stage, (int)rc,
                openni::OpenNI::getExtendedError());
    openni::OpenNI::shutdown();
    std::exit(code);
}

int main() {
    openni::Status rc = openni::OpenNI::initialize();
    if (rc != openni::STATUS_OK) die(2, "init", rc);

    openni::Device dev;
    rc = dev.open(openni::ANY_DEVICE);
    if (rc != openni::STATUS_OK) die(3, "open", rc);

    const openni::DeviceInfo& di = dev.getDeviceInfo();
    std::printf("device: %s (%s) usb %04x:%04x\n", di.getName(), di.getVendor(),
                di.getUsbVendorId(), di.getUsbProductId());

    openni::VideoStream depth;
    rc = depth.create(dev, openni::SENSOR_DEPTH);
    if (rc != openni::STATUS_OK) die(4, "depth-create", rc);
    rc = depth.start();
    if (rc != openni::STATUS_OK) die(5, "depth-start", rc);

    openni::VideoFrameRef frame;
    rc = depth.readFrame(&frame);
    if (rc != openni::STATUS_OK) die(6, "depth-read", rc);

    int w = frame.getWidth(), h = frame.getHeight();
    const openni::DepthPixel* p =
        (const openni::DepthPixel*)frame.getData();
    long nonzero = 0, samples = 0;
    for (long i = w / 2; i < (long)w * h; i += 7) { samples++; if (p[i] != 0) nonzero++; }
    std::printf("depth: %dx%d @%dfps  center=%dmm  valid-pixels=%ld%%\n",
                w, h, depth.getVideoMode().getFps(),
                (int)p[((long)h / 2) * w + w / 2], samples ? (nonzero * 100) / samples : 0);

    openni::VideoStream color;
    rc = color.create(dev, openni::SENSOR_COLOR);
    if (rc != openni::STATUS_OK) {
        std::printf("color: not available (depth-only unit?) msg=%s\n",
                    openni::OpenNI::getExtendedError());
        depth.stop(); depth.destroy(); dev.close();
        openni::OpenNI::shutdown();
        return 1;
    }
    rc = color.start();
    if (rc != openni::STATUS_OK) die(7, "color-start", rc);
    openni::VideoFrameRef cframe;
    rc = color.readFrame(&cframe);
    if (rc != openni::STATUS_OK) die(8, "color-read", rc);
    std::printf("color: %dx%d @%dfps\n", cframe.getWidth(), cframe.getHeight(),
                color.getVideoMode().getFps());

    color.stop(); color.destroy(); depth.stop(); depth.destroy();
    dev.close();
    openni::OpenNI::shutdown();
    return 0;
}
CEOF
    INCDIR="$(dirname "$HDR")"
    echo "  compiling the C++ probe (g++, against the staged libOpenNI2.so)..."
    if g++ -O2 -Wall "$LINKDIR/xtion_probe.cpp" -o "$LINKDIR/xtion_probe" \
         -I"$INCDIR" -L"$LINKDIR" -Wl,-rpath,"$LINKDIR" -lOpenNI2 2>"$LINKDIR/cc.log"; then
      echo "  running the probe (timeout 20 s)..."
      OUT="$(cd "$LINKDIR" && timeout 20 ./xtion_probe 2>&1)"
      RC=$?
      printf '%s\n' "$OUT" | sed 's/^/    /'
      case $RC in
        0) ok "frame grab OK: depth AND color streams verified - camera works"; GRAB_RESULT="depth+color" ;;
        1) ok "frame grab OK: depth verified; no color sensor (depth-only Xtion Pro)"; GRAB_RESULT="depth-only" ;;
        2) bad "could not initialize OpenNI 2 (library problem - see step 5)"; GRAB_RESULT="init-fail" ;;
        3) bad "OpenNI 2 found no device (permissions? PS1080 driver? see failures above)"
           hint "if it works with 'sudo', it is udev/group; otherwise reinstall openni2"
           GRAB_RESULT="no-device" ;;
        4|5|6) bad "depth stream failed on an opened device (rc=$RC)"; GRAB_RESULT="depth-fail" ;;
        7|8) warn "color stream failed after depth worked (rc=$RC)"; GRAB_RESULT="color-fail" ;;
        124) bad "no frame arrived within 20 s (camera stalled? try replug / another port)"; GRAB_RESULT="timeout" ;;
        *)  bad "probe exited with code $RC"; GRAB_RESULT="error" ;;
      esac
    else
      warn "the C++ probe did not compile:"
      sed 's/^/    /' "$LINKDIR/cc.log"
      hint "re-run with --python, or check that the openni2 package shipped its headers"
      GRAB_RESULT="compile-fail"
    fi
  fi
fi

# ---------------------------------------------------------- cleanup
[ -n "$REDIST" ] && rm -rf "$REDIST"
[ -n "$LINKDIR" ] && rm -rf "$LINKDIR"

# ---------------------------------------------------------- 7. viewer
step "7. Viewer"
VIEWER=''
for v in NiViewer2 NiViewer; do
  command -v "$v" >/dev/null 2>&1 && VIEWER="$v"
done
if [ -n "$VIEWER" ]; then
  echo "  $VIEWER available: $(command -v "$VIEWER")"
  if [ "$WANT_VIEWER" = 1 ]; then
    echo "  launching $VIEWER (close its window to exit)..."
    "$VIEWER"
  else
    echo "  re-run with --viewer (or run $VIEWER directly) for the visual test."
  fi
else
  echo "  NiViewer / NiViewer2 not in PATH."
  if [ "$WANT_VIEWER" = 1 ]; then
    warn "cannot launch a viewer - not installed"
    hint "the AUR openni2 package ships it as NiViewer2; otherwise build the OpenNI2 samples"
  else
    echo "  (not requested; the headless grab in step 6 is the real test)"
  fi
fi

# --------------------------------------------------------- summary
echo
echo "=================================================="
echo "RESULT: $PASS passed, $FAIL failed, $WARN warnings"
if [ "$FAIL" -eq 0 ] && { [ "$GRAB_RESULT" = "depth+color" ] || [ "$GRAB_RESULT" = "depth-only" ]; }; then
  echo "VERDICT: camera + stack are WORKING (${GRAB_RESULT})."
elif [ "$FAIL" -eq 0 ]; then
  echo "VERDICT: no failures detected (frame grab: $GRAB_RESULT)."
else
  echo "VERDICT: NOT working yet. Fix in this order:"
  i=1
  for s in "${NEXT_STEPS[@]}"; do echo "  $i. $s"; i=$((i+1)); done
fi
echo "=================================================="
[ "$FAIL" -eq 0 ]
