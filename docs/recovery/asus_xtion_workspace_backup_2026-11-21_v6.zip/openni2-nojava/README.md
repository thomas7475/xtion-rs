# openni2 2.2.0-3 — no-Java build

This is the AUR `openni2` package (2.2.0-2, reviewed and verified clean)
with one change: **the Java/doc parts of the build are removed**, so
installing it no longer pulls `java-environment` (a JDK). That JDK is what
conflicted with your installed `jre-openjdk` (`jdk-openjdk conflicts with
jre-openjdk`). Nothing functional is lost: Java was only used to build the
Java wrapper and the javadoc HTML, and the package never installed either
of those — all camera functionality (libOpenNI2, PS1080 driver, NiViewer2,
udev rules, headers, pkg-config) is C++ and unchanged.

## What changed vs the AUR PKGBUILD

- `depends`: dropped `java-environment`
- `makedepends`: dropped `doxygen` / `graphviz` (were only used by `make doc`)
- `prepare()`: dropped the Java-8 javadoc workaround (no doc build happens)
- `build()`: explicit C++ target list instead of `make` + `make doc`
- `package()`: dropped the doxygen-HTML doc install block
- `pkgrel` bumped 2 → 3

All 8 source entries and their sha256 pins are **identical to the AUR
package**: five patches are byte-identical to Debian's archive copies,
`0005` and `libopenni2.pc` were reconstructed to hash-match the AUR pins,
and the GitHub tarball hash was verified against the pin.

## Build & install

```bash
cd openni2-nojava
makepkg -si            # classic way (needs base-devel)
# or, with shelly:
shelly build -s -l     # mirrors makepkg -si
```

The build downloads the OpenNI 2.2.0 tarball from GitHub (~30 MB) and
compiles it. It installs:

- `/usr/lib/libOpenNI2.so` + `/usr/lib/OpenNI2/Drivers/` (PS1080, PSLink,
  OniFile, DummyDevice drivers)
- `/usr/bin/NiViewer2` and the sample binaries
- `/usr/lib/udev/rules.d/60-openni2-usb.rules` (covers 1d27:0601)
- `/usr/include/openni2/` headers, `/usr/lib/pkgconfig/libopenni2.pc`
- `/etc/openni2/` config files

After installing: unplug and replug the camera, then run
`./xtion_test_cachyos.sh` for the full health check and frame-grab test.

## If you ever want the original AUR package back

`shelly install aur openni2` — it will ask to swap your `jre-openjdk` for
`jdk-openjdk` (the JDK also provides `java-runtime`, so Java apps keep
working). Or keep this build: it is the same package, just without the
unused Java build steps.
